const express = require('express');
const cors = require('cors');
const fs = require('fs');

const app = express();

// Middleware
app.use(cors());

// Create test file
const testFilePath = __dirname + '/test-file.bin';
if (!fs.existsSync(testFilePath)) {
    const buffer = Buffer.alloc(10 * 1024 * 1024, 'A'); // 10MB file
    fs.writeFileSync(testFilePath, buffer);
}

// Routes
app.get('/', (req, res) => {
    res.json({ message: 'WiFi Fly API is running' });
});

// Serve test file for speed test
app.get('/api/speed-test-file', (req, res) => {
    res.sendFile(testFilePath);
});

// Start server
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
