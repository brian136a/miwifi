import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import WelcomeScreen from './components/WelcomeScreen';
import TestScreen from './components/TestScreen';
import ResultsScreen from './components/ResultsScreen';
import './App.css';

// Firebase configuration
import { initializeApp } from 'firebase/app';

const firebaseConfig = {
  apiKey: "AIzaSyBR_V0eDMj8sSPZhtFX1yQNH8cQkXP5H8o",
  authDomain: "wififly-dev.firebaseapp.com",
  projectId: "wififly-dev",
  storageBucket: "wififly-dev.firebasestorage.app",
  messagingSenderId: "174095602373",
  appId: "1:174095602373:web:7e45f7ba0ba5d683a7d6ac"
};

const app = initializeApp(firebaseConfig);

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <nav className="bg-white shadow">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex">
                <div className="flex-shrink-0 flex items-center">
                  <h1 className="text-xl font-bold text-gray-900">WiFiFly</h1>
                </div>
              </div>
            </div>
          </div>
        </nav>
        <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          <Routes>
            <Route path="/" element={<WelcomeScreen />} />
            <Route path="/test" element={<TestScreen />} />
            <Route path="/results" element={<ResultsScreen />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
