import React, { useState, useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

function TestScreen() {
  const [roomNames, setRoomNames] = useState({
    left: 'Room 1',
    center: 'Room 2',
    right: 'Room 3'
  });
  const [testResults, setTestResults] = useState({
    left: null,
    center: null,
    right: null
  });
  const [isTesting, setIsTesting] = useState(false);

  const testSpeed = async (position) => {
    setIsTesting(true);
    try {
      const startTime = performance.now();
      const response = await fetch('http://localhost:5000/api/speed-test-file');
      const blob = await response.blob();
      const endTime = performance.now();
      
      const duration = (endTime - startTime) / 1000;
      const speed = (10 * 8) / duration; // 10MB file, convert to Mbps
      
      setTestResults(prev => ({
        ...prev,
        [position]: speed
      }));
    } catch (error) {
      console.error('Speed test failed:', error);
    } finally {
      setIsTesting(false);
    }
  };

  const getColorClass = (speed) => {
    if (speed === null) return 'room-button-pending';
    if (speed >= 50) return 'room-button-fast';
    if (speed >= 20) return 'room-button-medium';
    return 'room-button-slow';
  };

  const getSpeedCategory = (speed) => {
    if (speed === null) return 'Pending';
    if (speed >= 50) return 'Fast';
    if (speed >= 20) return 'Medium';
    return 'Slow';
  };

  const chartData = {
    labels: ['Room 1', 'Room 2', 'Room 3'],
    datasets: [
      {
        label: 'Speed (Mbps)',
        data: [testResults.left, testResults.center, testResults.right],
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
        tension: 0.1,
      },
    ],
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Room 1</h2>
        <input
          type="text"
          value={roomNames.left}
          onChange={(e) => setRoomNames(prev => ({ ...prev, left: e.target.value }))}
          className="input-field"
          placeholder="Enter room name"
        />
        <button
          onClick={() => testSpeed('left')}
          className={`room-button ${getColorClass(testResults.left)}`}
          disabled={isTesting}
        >
          {isTesting ? 'Testing...' : `Test Speed (${getSpeedCategory(testResults.left)})`}
        </button>
        {testResults.left !== null && (
          <div className="speed-result">
            {testResults.left.toFixed(2)} Mbps
          </div>
        )}
      </div>

      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Room 2</h2>
        <input
          type="text"
          value={roomNames.center}
          onChange={(e) => setRoomNames(prev => ({ ...prev, center: e.target.value }))}
          className="input-field"
          placeholder="Enter room name"
        />
        <button
          onClick={() => testSpeed('center')}
          className={`room-button ${getColorClass(testResults.center)}`}
          disabled={isTesting}
        >
          {isTesting ? 'Testing...' : `Test Speed (${getSpeedCategory(testResults.center)})`}
        </button>
        {testResults.center !== null && (
          <div className="speed-result">
            {testResults.center.toFixed(2)} Mbps
          </div>
        )}
      </div>

      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Room 3</h2>
        <input
          type="text"
          value={roomNames.right}
          onChange={(e) => setRoomNames(prev => ({ ...prev, right: e.target.value }))}
          className="input-field"
          placeholder="Enter room name"
        />
        <button
          onClick={() => testSpeed('right')}
          className={`room-button ${getColorClass(testResults.right)}`}
          disabled={isTesting}
        >
          {isTesting ? 'Testing...' : `Test Speed (${getSpeedCategory(testResults.right)})`}
        </button>
        {testResults.right !== null && (
          <div className="speed-result">
            {testResults.right.toFixed(2)} Mbps
          </div>
        )}
      </div>

      <div className="col-span-3">
        <div className="chart-container">
          <Line data={chartData} />
        </div>
      </div>
    </div>
  );
}

export default TestScreen;
