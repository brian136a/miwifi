import React from 'react';
import { useNavigate } from 'react-router-dom';

function WelcomeScreen() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">WiFiFly</h1>
        <p className="text-xl mb-8">WiFi Testing and Diagnostics Tool</p>
        
        <div className="space-y-4">
          <button
            onClick={() => navigate('/test')}
            className="speed-test-button px-8 py-4 text-xl"
          >
            Start Speed Test
          </button>
          <button
            onClick={() => navigate('/results')}
            className="speed-test-button px-8 py-4 text-xl bg-gray-600 hover:bg-gray-700"
          >
            View Results
          </button>
        </div>
      </div>
    </div>
  );
}

export default WelcomeScreen;
