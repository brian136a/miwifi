import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getFirestore, collection, addDoc } from 'firebase/firestore';

function ResultsScreen() {
  const navigate = useNavigate();
  const [contactInfo, setContactInfo] = useState({
    name: '',
    email: '',
    phone: ''
  });
  const [testResults, setTestResults] = useState(JSON.parse(localStorage.getItem('testResults') || '{}'));
  const [roomNames, setRoomNames] = useState(JSON.parse(localStorage.getItem('roomNames') || '{}'));
  const [quoteSubmitted, setQuoteSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const db = getFirestore();
      await addDoc(collection(db, 'quotes'), {
        results: testResults,
        roomNames,
        contactInfo,
        timestamp: new Date()
      });
      setQuoteSubmitted(true);
    } catch (error) {
      console.error('Error submitting quote:', error);
      alert('Failed to submit quote. Please try again.');
    }
  };

  const generateRecommendations = () => {
    const recommendations = [];
    const speeds = Object.values(testResults);
    const avgSpeed = speeds.reduce((a, b) => a + (b || 0), 0) / speeds.length;

    if (avgSpeed < 20) {
      recommendations.push('Consider upgrading your internet plan');
    }
    if (Math.max(...speeds) - Math.min(...speeds) > 20) {
      recommendations.push('Check for WiFi interference in rooms with slower speeds');
    }
    if (avgSpeed > 50) {
      recommendations.push('Your WiFi speeds are excellent! No immediate action needed.');
    }

    return recommendations;
  };

  const exportToCSV = () => {
    const csvContent = [
      ['Room', 'Speed (Mbps)', 'Category'],
      ...Object.entries(testResults).map(([position, speed]) => [
        roomNames[position],
        speed?.toFixed(2) || 'N/A',
        getSpeedCategory(speed)
      ])
    ];

    const csv = csvContent.map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('href', url);
    a.setAttribute('download', 'wifi_test_results.csv');
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const getSpeedCategory = (speed) => {
    if (speed === null) return 'Pending';
    if (speed >= 50) return 'Fast';
    if (speed >= 20) return 'Medium';
    return 'Slow';
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Test Results</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {Object.entries(testResults).map(([position, speed]) => (
          <div key={position} className="p-6 bg-white rounded-lg shadow">
            <h2 className="text-xl font-bold mb-4">{roomNames[position] || `Room ${position}`}</h2>
            <div className="speed-result mb-4">{speed?.toFixed(2) || 'N/A'} Mbps</div>
            <div className="text-lg mb-4">Category: {getSpeedCategory(speed)}</div>
          </div>
        ))}
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Recommendations</h2>
        <ul className="list-disc list-inside">
          {generateRecommendations().map((rec, index) => (
            <li key={index} className="mb-2">{rec}</li>
          ))}
        </ul>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Contact Information</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="form-group">
            <label className="block text-sm font-medium">Name</label>
            <input
              type="text"
              value={contactInfo.name}
              onChange={(e) => setContactInfo(prev => ({ ...prev, name: e.target.value }))}
              className="input-field"
            />
          </div>
          <div className="form-group">
            <label className="block text-sm font-medium">Email</label>
            <input
              type="email"
              value={contactInfo.email}
              onChange={(e) => setContactInfo(prev => ({ ...prev, email: e.target.value }))}
              className="input-field"
            />
          </div>
          <div className="form-group">
            <label className="block text-sm font-medium">Phone</label>
            <input
              type="tel"
              value={contactInfo.phone}
              onChange={(e) => setContactInfo(prev => ({ ...prev, phone: e.target.value }))}
              className="input-field"
            />
          </div>

          <div className="flex justify-between">
            <button
              type="button"
              onClick={exportToCSV}
              className="submit-button bg-gray-600 hover:bg-gray-700"
            >
              Export to CSV
            </button>
            <button
              type="submit"
              className="submit-button"
              disabled={quoteSubmitted}
            >
              {quoteSubmitted ? 'Quote Submitted' : 'Submit Quote'}
            </button>
          </div>
        </form>
      </div>

      <button
        onClick={() => navigate('/test')}
        className="submit-button"
      >
        Run Another Test
      </button>
    </div>
  );
}

export default ResultsScreen;
